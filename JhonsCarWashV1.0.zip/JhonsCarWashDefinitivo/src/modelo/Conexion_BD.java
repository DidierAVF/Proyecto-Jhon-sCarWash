package modelo;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Conexion_BD {

    ArrayList<clientes> personas = new ArrayList<clientes>();
    private static java.sql.Connection conn;
    private static final String driver = "com.mysql.jdbc.Driver";

    public Conexion_BD() {

        conn = null;

        try {
            Class.forName(driver);
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/autolavado", "root", "");
            if (conn != null) {
                System.out.println("Conexion Establecida..");
            }

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar" + e);
        }

    }

    public java.sql.Connection getConnection() {
        return conn;
    }

    public void desconectar() {
        conn = null;
        if (conn == null) {
            System.out.println("Conexion Terminada");
        }
    }

}
