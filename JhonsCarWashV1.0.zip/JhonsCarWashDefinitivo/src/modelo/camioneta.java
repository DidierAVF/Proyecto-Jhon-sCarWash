/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Pc
 */
public class camioneta extends vehiculo {

    private long PrecioCamioneta = 24000;

    public camioneta() {
    }

    public camioneta(String placa) {
        super(placa);
    }

    public long getPrecioCamioneta() {
        return PrecioCamioneta;
    }

    public void setPrecioCamioneta(long PrecioCamioneta) {
        this.PrecioCamioneta = PrecioCamioneta;
    }

    @Override
    public String toString() {
        return "camioneta{" + "PrecioCamioneta=" + PrecioCamioneta + '}';
    }

    @Override
    public double PrecioVehiculo(int Digitos) {

        LocalDate fechaActual = LocalDate.now();
        int day = fechaActual.getDayOfMonth();
        long Total = 0;
        if (Digitos == day) {
            Total = ((long) (this.PrecioCamioneta * 0.15) * -1) + this.PrecioCamioneta;
        } else {
            Total = (long) this.PrecioCamioneta;
        }
        return Total;
    }

    @Override
    public double PrecioPorVehiculo(int count) {
        double total = count * this.PrecioCamioneta;

        return total;
    }

}
