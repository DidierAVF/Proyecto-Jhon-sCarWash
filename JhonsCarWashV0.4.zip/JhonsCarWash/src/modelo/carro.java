/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Pc
 */
public class carro extends vehiculo{

    public carro() {
    }

    public carro(String placa) {
        super(placa);
    }

    @Override
    public String toString() {
        return "carro{" + '}';
    }

    @Override
    public double PrecioPromo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
