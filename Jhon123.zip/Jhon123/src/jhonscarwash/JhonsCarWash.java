/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jhonscarwash;

import modelo.Conexion_BD;
import java.sql.SQLException;
import modelo.autolavado;
import modelo.menu;
import visual.Factura;
import visual.Login;
import visual.MenuAdmin;
import visual.Prueba;

/**
 *
 * @author Pc
 */
public class JhonsCarWash {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        /*menu o=new menu();
        o.menus();*/
       
        Login L = new Login();
        L.setVisible(true);
        /*MenuAdmin M = new MenuAdmin();
        M.setVisible(false);
        //Conexion_BD BD = new Conexion_BD();
        //BD.ConexionBD();*/
        Factura F = new Factura();
        F.setVisible(true);
    }
    
}
