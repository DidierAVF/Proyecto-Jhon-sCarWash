
package modelo;

public abstract class vehiculo {
    
    private String placa;
    private String nombre;
    private long cedula;
    private int cantidaddelavadas;


    public vehiculo() {
    }

    public vehiculo(String placa) {
        this.placa = placa;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    @Override
    public String toString() {
        return "vehiculo{" + "placa=" + placa + '}';
    }
    
    public void ImpreFactura(){}
    
    abstract public double PrecioVehiculo(int count);
  
 
    
    public long TotalPorVehiculo(){
    return 0;
    
    }
    
    public long TotalDia(){
    return 0;
    }
    
    
    
    
    
    
}
