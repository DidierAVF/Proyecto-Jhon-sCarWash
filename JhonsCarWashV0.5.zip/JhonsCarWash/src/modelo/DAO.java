/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Pc
 */
public class DAO {
     private ResultSet RS;
    Conexion_BD cc = new Conexion_BD();
    Connection con = cc.getConnection();
    private PreparedStatement PS;
    
    public void register(String nombre1, String cedula1, String Placa1, String radio1){
           String Nombre = nombre1;
           int Cedula =Integer.parseInt(cedula1);
           String Placa= Placa1;
           String Tipo=radio1;
           int Asistencias=0;
          // if(radio1=="Moto"){
           //Tipo=1;
          // }
         //  if(radio1=="Carro"){
         //  Tipo=2;
          // }
         //  if(radio1=="Camioneta"){
         //  Tipo=3;
         //  }
           
          System.out.println("aa"+Nombre);
           System.out.println("aa"+Cedula);
           System.out.println("aa"+Placa);
           System.out.println("aa"+Tipo);
           
           String SQL = "INSERT INTO clientes(Nombre, Cedula, Placa, Tipo, Asistencias) VALUES (?,?,?,?,?)";
           try{
               PreparedStatement pst = con.prepareStatement(SQL);
               pst.setString(1,Nombre);
               pst.setInt(2,Cedula);
               pst.setString(3,Placa);
               pst.setString(4,Tipo);
                pst.setInt(5,Asistencias);
               pst.executeUpdate();
               JOptionPane.showMessageDialog(null, "Se inserto con exito");
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, "Error de conexion"+e.getMessage());
           }
        
    }
    
        public ArrayList<clientes> almacenardatosBD() {
        ArrayList<clientes> clientList = new ArrayList<>();
        String SQL = "SELECT Nombre, Cedula, Placa, Tipo FROM clientes";
        try {
            PS = con.prepareStatement(SQL);
            RS = PS.executeQuery();
            while (RS.next()) {
                String nombre = RS.getString("Nombre");
                int cedula = RS.getInt("Cedula");
                String placa = RS.getString("Placa");
                String tipo = RS.getString("Tipo");

                clientes cliente = new clientes(nombre, placa, cedula, tipo);
                clientList.add(cliente);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching data" + e.getMessage());
        }
        return clientList;
    }
        
          public void borrarClientePorCedula(String cedula1) {
               int cedula=Integer.parseInt(cedula1);
        
            String SQL = "DELETE FROM clientes WHERE Cedula = ?";
            try {
                PS = con.prepareStatement(SQL);
                PS.setInt(1, cedula);
                PS.executeUpdate();
                JOptionPane.showMessageDialog(null, "Cliente con cédula " + cedula + " eliminado correctamente.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al eliminar cliente: " + e.getMessage());
            }
       
    }
        
        
    
    
    }