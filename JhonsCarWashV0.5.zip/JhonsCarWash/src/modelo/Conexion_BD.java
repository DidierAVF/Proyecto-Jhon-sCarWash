/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Paula
 */
public class Conexion_BD {
    
     ArrayList<clientes> personas = new ArrayList<clientes>();
   private static java.sql.Connection  conn;
 private static final String driver="com.mysql.jdbc.Driver";

 public Conexion_BD(){
     
     conn = null;
 
  try{
     Class.forName(driver);
     conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/autolavado","root","");
     if(conn != null){
         System.out.println("Conexion Establecida..");
     }
     
   } catch (ClassNotFoundException | SQLException e){
       System.out.println("Error al conectar"+e);
   }

}
 /*Metodo que retorna la coneccion*/
 public java.sql.Connection getConnection(){
  return conn;
}
  /*Metodo para desconectarnos de la base de datos*/
public void desconectar(){
  conn = null;
  if(conn==null){
      System.out.println("Conexion Terminada");
  }
 }
 


 
}