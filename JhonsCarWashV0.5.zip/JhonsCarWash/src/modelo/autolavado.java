package modelo;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.camioneta;
import modelo.carro;
import modelo.menu;
import modelo.moto;
import modelo.usuario;

public class autolavado {
    
     DAO comidao=new DAO();

    private ArrayList<carro> Carros = new ArrayList<carro>();
    private ArrayList<moto> Motos = new ArrayList<moto>();
    private ArrayList<camioneta> Camionetas = new ArrayList<camioneta>();
    private ArrayList<usuario> Usuarios = new ArrayList<usuario>();
    private boolean Cubiculo [] = new boolean [8];

    public autolavado() {
        this.Carros = new ArrayList<>();
        this.Motos = new ArrayList<>();
        this.Camionetas = new ArrayList<>();
        this.Usuarios = new ArrayList<>();
        this.Cubiculo= new boolean [8];
    }
    

    public ArrayList<carro> getCarros() {
        return Carros;
    }

    public void setCarros(ArrayList<carro> carros) {
        this.Carros = carros;
    }

    public ArrayList<moto> getMotos() {
        return Motos;
    }

    public void setMotos(ArrayList<moto> motos) {
        this.Motos = motos;
    }

    public ArrayList<camioneta> getCamionetas() {
        return Camionetas;
    }

    public void setCamionetas(ArrayList<camioneta> camionetas) {
        this.Camionetas = camionetas;
    }

    public ArrayList<usuario> getUsuarios() {
        return Usuarios;
    }

    public void setUsuarios(ArrayList<usuario> usuarios) {
        this.Usuarios = usuarios;
    }



    public boolean registrar(String nombre, String cedula, String Placa, String radio1) {
      
        int Cedula1=Integer.parseInt(cedula);
        
       boolean re= verificarCedula(Cedula1);
                System.out.println(""+nombre+cedula+Placa+radio1);

       if(re==true){
       
       comidao.register(nombre, cedula,Placa, radio1);
               System.out.println(""+nombre+cedula+Placa+radio1);

       }
                System.out.println(""+nombre+cedula+Placa+radio1);

        return false;
        
        
    }

    public int verificarcredenciales(String usuario, String contraseña) {
        usuario o = new usuario();
        if (o.getAdminusuario().equals(usuario) && o.getAdmincontraseña().equals(contraseña) ) {
            return 1;
        }else if (o.getUsuario().equals(usuario) && o.getContraseña().equals(contraseña)){
            return 2;
        }
        return 3;

    }

      public boolean verificarCedula(int cedula) {
        if (cedula >= 0) {
            return true;
        }
                System.out.println("a"+cedula);

        return false;
    }
      
      
      
        public boolean verificarCedulaExiste(String cedula) {
            DAO pe=new DAO();
            ArrayList<clientes> cedulaa = pe.almacenardatosBD();
            int ce=Integer.parseInt(cedula);
            
            for (int i = 0; i < cedulaa.size(); i++) {
                if(cedulaa.get(i).getCedula()==ce){
                return true;
                }
                
            }
            
            
        return false;
    }
      
      
      
      
      
      

    public void listar() {

    }

    public void eliminar() {

    }

    public void cubiculos() {

    }

    public void imprimirganancias() {

    }
}
