/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Pc
 */
public class clientes {
    private String nombre;
    private String placa;
    private int cedula;
    private String tipo;

    public clientes() {
    }

    public clientes(String nombre, String placa, int cedula, String tipo) {
        this.nombre = nombre;
        this.placa = placa;
        this.cedula = cedula;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "clientes{" + "nombre=" + nombre + ", placa=" + placa + ", cedula=" + cedula + ", tipo=" + tipo + '}';
    }

   
    
    
    
}
