package control;

import modelo.DAO;
import modelo.autolavado;
import visual.Login;

public class Controlador {

    autolavado comiautolavado = new autolavado();
    DAO comidao = new DAO();

    public int VerifiAdmin(String Usuario, String Contraseña) {
        autolavado Auto = new autolavado();
        int Vali = Auto.verificarcredenciales(Usuario, Contraseña);
        return Vali;
    }

   public String registro(String nombre, String cedula, String Placa, String radio1, String Cubiculo) {
        boolean re = comiautolavado.verificarCedulaExiste(cedula);
        if (re == true) {
             return "ERROR";
        } else {
            comiautolavado.registrar(nombre, cedula, Placa, radio1, Cubiculo);
          
        }
        return "e";
    }


    public String cedula(String cedula) {

        boolean re = comiautolavado.verificarCedulaExiste(cedula);
        if (re == true) {
            comidao.borrarClientePorCedula(cedula);
        } else {
            return "ERROR";
        }
        return "e";

    }

    public String vaciarcubi(String cubiculo) {

        comidao.actualizarAsistencias(cubiculo);

        return "e";

    }

    public String[] controladorfactura() {
        String[] facturaimprimir = new String[12];

        facturaimprimir = comiautolavado.factura();
        return facturaimprimir;
    }

    public String[] controladorganancias() {
        String[] gananciasimprimir = new String[4];

        gananciasimprimir = comiautolavado.ganancias();

        return gananciasimprimir;
    }
    
    
}
