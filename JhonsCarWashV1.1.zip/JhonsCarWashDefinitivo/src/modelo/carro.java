/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Pc
 */
public class carro extends vehiculo {

    private long PrecioCarro = 20000;

    public carro() {
    }

    public carro(String placa) {
        super(placa);
    }

    public long getPrecioCarro() {
        return PrecioCarro;
    }

    public void setPrecioCarro(long PrecioCarro) {
        this.PrecioCarro = PrecioCarro;
    }

    @Override
    public String toString() {
        return "carro{" + "PrecioCarro=" + PrecioCarro + '}';
    }

    @Override
    public double PrecioVehiculo(int Digitos) {
        LocalDate fechaActual = LocalDate.now();
        int day = fechaActual.getDayOfMonth();
        long Total = 0;
        if (Digitos == day) {
            Total = ((long) (this.PrecioCarro * 0.15) * -1) + this.PrecioCarro;
        } else {
            Total = (long) this.PrecioCarro;
        }

        return Total;
    }

    @Override
    public double PrecioPorVehiculo(int count) {
        double total = count * this.PrecioCarro;

        return total;
    }

}
