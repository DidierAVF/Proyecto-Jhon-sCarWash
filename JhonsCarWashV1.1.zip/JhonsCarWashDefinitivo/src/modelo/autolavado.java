package modelo;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.camioneta;
import modelo.carro;
import modelo.moto;
import modelo.usuario;
import java.time.LocalDate;
import java.util.Random;
import javax.swing.JOptionPane;

public class autolavado {

    DAO comidao = new DAO();

    private ArrayList<carro> Carros = new ArrayList<carro>();
    private ArrayList<moto> Motos = new ArrayList<moto>();
    private ArrayList<camioneta> Camionetas = new ArrayList<camioneta>();
    private ArrayList<usuario> Usuarios = new ArrayList<usuario>();
    private boolean Cubiculo[] = new boolean[8];

    public autolavado() {
        this.Carros = new ArrayList<>();
        this.Motos = new ArrayList<>();
        this.Camionetas = new ArrayList<>();
        this.Usuarios = new ArrayList<>();
        this.Cubiculo = new boolean[8];
    }

    public ArrayList<carro> getCarros() {
        return Carros;
    }

    public void setCarros(ArrayList<carro> carros) {
        this.Carros = carros;
    }

    public ArrayList<moto> getMotos() {
        return Motos;
    }

    public void setMotos(ArrayList<moto> motos) {
        this.Motos = motos;
    }

    public ArrayList<camioneta> getCamionetas() {
        return Camionetas;
    }

    public void setCamionetas(ArrayList<camioneta> camionetas) {
        this.Camionetas = camionetas;
    }

    public ArrayList<usuario> getUsuarios() {
        return Usuarios;
    }

    public void setUsuarios(ArrayList<usuario> usuarios) {
        this.Usuarios = usuarios;
    }

    public boolean registrar(String nombre, String cedula, String Placa, String radio1, String Cubiculo) {

        int Cedula1 = Integer.parseInt(cedula);

        boolean re = verificarCedula(Cedula1);
        System.out.println("" + nombre + cedula + Placa + radio1);

        if (re == true) {

            comidao.register(nombre, cedula, Placa, radio1, Cubiculo);
            System.out.println("" + nombre + cedula + Placa + radio1);

        }
        System.out.println("" + nombre + cedula + Placa + radio1);

        return false;

    }

    public int verificarcredenciales(String usuario, String contraseña) {
        usuario o = new usuario();
        if (o.getAdminusuario().equals(usuario) && o.getAdmincontraseña().equals(contraseña)) {
            return 1;
        } else if (o.getUsuario().equals(usuario) && o.getContraseña().equals(contraseña)) {
            return 2;
        }
        return 3;

    }

    public boolean verificarCedula(int cedula) {
        if (cedula >= 0) {
            return true;
        }
        System.out.println("a" + cedula);

        return false;
    }

    public boolean verificarCedulaExiste(String cedula) {
        DAO pe = new DAO();
        ArrayList<clientes> cedulaa = pe.almacenardatosBD();
        int ce = Integer.parseInt(cedula);

        for (int i = 0; i < cedulaa.size(); i++) {
            if (cedulaa.get(i).getCedula() == ce) {
                return true;
            }

        }

        return false;
    }

    public String[] factura() {
        ArrayList<clientes> clientespe = comidao.almacenardatosBD();

        String[] facturaimprimirproceso = new String[12];

        LocalDate fechaActual = LocalDate.now();
        int year = fechaActual.getYear();
        int month = fechaActual.getMonthValue();
        int day = fechaActual.getDayOfMonth();
        String Dia = String.valueOf(day);
        String mes = String.valueOf(month);
        String año = String.valueOf(year);
        facturaimprimirproceso[7] = Dia;
        facturaimprimirproceso[8] = mes;
        facturaimprimirproceso[9] = año;

        if (clientespe != null && !clientespe.isEmpty()) {
            String nfactura = Integer.toString(clientespe.size());
            facturaimprimirproceso[0] = nfactura;

            clientes ultimoCliente = clientespe.get(clientespe.size() - 1);
            facturaimprimirproceso[10] = ultimoCliente.getNombre();
            facturaimprimirproceso[11] = ultimoCliente.getPlaca();

            String cedulawa = Integer.toString(ultimoCliente.getCedula());
            facturaimprimirproceso[1] = cedulawa;

            int cedula = ultimoCliente.getCedula();
            cedula = cedula % 100;
            String Cubiculo2 = Integer.toString(ultimoCliente.getAsistencia());
            facturaimprimirproceso[2] = Cubiculo2;

            String tipo = ultimoCliente.getTipo();
            facturaimprimirproceso[3] = tipo;

            for (int i = 0; i < clientespe.size(); i++) {
                if (clientespe.get(i).getTipo().equals("Moto")) {
                    moto m = new moto();
                    System.out.println("" + cedula);
                    String Precio = Integer.toString((int) m.PrecioVehiculo(cedula));
                    System.out.println("" + Precio);
                    facturaimprimirproceso[4] = Precio;

                    int min = 12000;
                    int max = 50000;
                    Random random = new Random();
                    int numeroAzar;
                    do {
                        numeroAzar = random.nextInt((max - min) + 1) + min;
                    } while (numeroAzar % 50 != 0);
                    String numazar = String.valueOf(numeroAzar);
                    facturaimprimirproceso[5] = numazar;

                    int resultado = numeroAzar - min;
                    String re = Integer.toString(resultado);
                    facturaimprimirproceso[6] = re;
                }
                if (clientespe.get(i).getTipo().equals("Carro")) {
                    carro c = new carro();
                    String Precio = Integer.toString((int) c.PrecioVehiculo(cedula));
                    facturaimprimirproceso[4] = Precio;

                    int min = 20000;
                    int max = 50000;
                    Random random = new Random();
                    int numeroAzar;
                    do {
                        numeroAzar = random.nextInt((max - min) + 1) + min;
                    } while (numeroAzar % 50 != 0);
                    String numazar = String.valueOf(numeroAzar);
                    facturaimprimirproceso[5] = numazar;

                    int resultado = numeroAzar - 20000;
                    String re = Integer.toString(resultado);
                    facturaimprimirproceso[6] = re;
                }
                if (clientespe.get(i).getTipo().equals("Camioneta")) {
                    camioneta ca = new camioneta();
                    String Precio = Integer.toString((int) ca.PrecioVehiculo(cedula));
                    facturaimprimirproceso[4] = Precio;

                    int min = 24000;
                    int max = 50000;
                    Random random = new Random();
                    int numeroAzar;
                    do {
                        numeroAzar = random.nextInt((max - min) + 1) + min;
                    } while (numeroAzar % 50 != 0);
                    String numazar = String.valueOf(numeroAzar);
                    facturaimprimirproceso[5] = numazar;

                    int resultado = numeroAzar - 24000;
                    String re = Integer.toString(resultado);
                    facturaimprimirproceso[6] = re;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados o hubo un error al obtener los datos.");
        }

        return facturaimprimirproceso;
    }

    public String[] ganancias() {
        String[] gananciasimprimir = new String[4];

        ArrayList<moto> motoo = comidao.almacenarmoto();
        ArrayList<carro> carroo = comidao.almacenarcarro();
        ArrayList<camioneta> camionetaa = comidao.almacenarcamioneta();
        int count1 = motoo.size();
        int count2 = carroo.size();
        int count3 = camionetaa.size();

        double totalmoto1 = (count1 > 0) ? motoo.get(0).PrecioPorVehiculo(count1) : 0;
        String totalmotoall = Double.toString(totalmoto1);

        double totalcarroo1 = (count2 > 0) ? carroo.get(0).PrecioPorVehiculo(count2) : 0;
        String totalcarroall = Double.toString(totalcarroo1);

        double totalcamioneta1 = (count3 > 0) ? camionetaa.get(0).PrecioPorVehiculo(count3) : 0;
        String totalcamionetaall = Double.toString(totalcamioneta1);

        double totalgan = totalmoto1 + totalcarroo1 + totalcamioneta1;
        String totalganancidia = Double.toString(totalgan);

        gananciasimprimir[0] = totalmotoall;
        gananciasimprimir[1] = totalcarroall;
        gananciasimprimir[2] = totalcamionetaall;
        gananciasimprimir[3] = totalganancidia;

        return gananciasimprimir;
    }

}
