
package visual;

import control.Controlador;
import java.awt.Color;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Login extends javax.swing.JFrame {

    Controlador Controlador = new Controlador();
    
    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Base = new javax.swing.JPanel();
        Iniciarsesion = new javax.swing.JLabel();
        UsuarioTexto = new javax.swing.JLabel();
        ContraseñaTexto = new javax.swing.JLabel();
        Usuario = new javax.swing.JTextField();
        SeparadorCon = new javax.swing.JSeparator();
        SeparadorUsu = new javax.swing.JSeparator();
        LoginTexto = new javax.swing.JLabel();
        Contraseña = new javax.swing.JPasswordField();
        ImagenLogo = new javax.swing.JLabel();
        BotonIngresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));
        setLocationByPlatform(true);
        setResizable(false);

        Base.setBackground(new java.awt.Color(255, 255, 255));
        Base.setRequestFocusEnabled(false);
        Base.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Iniciarsesion.setFont(new java.awt.Font("Arial Black", 0, 38)); // NOI18N
        Iniciarsesion.setText("INICIAR SESIÓN");
        Base.add(Iniciarsesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        UsuarioTexto.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 20)); // NOI18N
        UsuarioTexto.setText("USUARIO");
        Base.add(UsuarioTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        ContraseñaTexto.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 20)); // NOI18N
        ContraseñaTexto.setText("CONTRASEÑA");
        ContraseñaTexto.setToolTipText("");
        Base.add(ContraseñaTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, -1, -1));

        Usuario.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        Usuario.setForeground(new java.awt.Color(204, 204, 204));
        Usuario.setText("Ingrese su nombre de usuario");
        Usuario.setBorder(null);
        Usuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Usuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuarioMousePressed(evt);
            }
        });
        Base.add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 300, 30));

        SeparadorCon.setForeground(new java.awt.Color(0, 0, 0));
        Base.add(SeparadorCon, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 300, 20));

        SeparadorUsu.setForeground(new java.awt.Color(0, 0, 0));
        Base.add(SeparadorUsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 300, 20));

        LoginTexto.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        LoginTexto.setText("Login");
        Base.add(LoginTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        Contraseña.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(204, 204, 204));
        Contraseña.setText("********"); // NOI18N
        Contraseña.setBorder(null);
        Contraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Contraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ContraseñaMousePressed(evt);
            }
        });
        Base.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 300, 30));

        ImagenLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Logo (1).png"))); // NOI18N
        Base.add(ImagenLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 400, 500));

        BotonIngresar.setBackground(new java.awt.Color(204, 255, 255));
        BotonIngresar.setFont(new java.awt.Font("Arial Black", 0, 22)); // NOI18N
        BotonIngresar.setText("INGRESAR");
        BotonIngresar.setBorder(null);
        BotonIngresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonIngresarActionPerformed(evt);
            }
        });
        Base.add(BotonIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 150, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Base, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Base, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuarioMousePressed
        if(Usuario.getText().equals("Ingrese su nombre de usuario")){
        Usuario.setText("");
        Usuario.setForeground(Color.black);
        }
        if(String.valueOf(Contraseña.getPassword()).isEmpty()){
        Contraseña.setText("********");
        Contraseña.setForeground(Color.gray);
        }
    }//GEN-LAST:event_UsuarioMousePressed

    private void ContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContraseñaMousePressed
        if(Usuario.getText().isEmpty()){
        Usuario.setText("Ingrese su nombre de usuario");
        Usuario.setForeground(Color.gray);
        }
        if(String.valueOf(Contraseña.getPassword()).equals("********")){
        Contraseña.setText("");
        Contraseña.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_ContraseñaMousePressed

    private void BotonIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonIngresarActionPerformed
        
        String Usuarios1;
        String Contraseña1;
        //do{
            Usuarios1=Usuario.getText();
            Contraseña1=String.valueOf(Contraseña.getPassword());
            if (Usuarios1.equalsIgnoreCase("Ingrese su nombre de usuario")&& Contraseña1.equalsIgnoreCase("********")) {
                JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacios");
            } else if (Usuarios1.equalsIgnoreCase("") || Usuarios1.equalsIgnoreCase("Ingrese su nombre de usuario")) {
                JOptionPane.showMessageDialog(null, "Debe ingresar Usuario");
            } else if(Contraseña1.equalsIgnoreCase("") || Contraseña1.equalsIgnoreCase("********") ) {
                JOptionPane.showMessageDialog(null, "Debe ingresar Contraseña");
            }else{Controlador con =new Controlador();
            int vali=con.VerifiAdmin(Usuarios1, Contraseña1);
            if(vali==1){
               MenuAdmin menad=new MenuAdmin();
               menad.setVisible(true);
               setVisible(false);
            }else if(vali==2){
                MenuEmpleado men=new MenuEmpleado();
                men.setVisible(true);
                setVisible(false);
            }else{
                    JOptionPane.showMessageDialog(null, "Usuario y contraseña invalidas");
                }
            }
    
    }//GEN-LAST:event_BotonIngresarActionPerformed
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Base;
    private javax.swing.JButton BotonIngresar;
    private javax.swing.JPasswordField Contraseña;
    private javax.swing.JLabel ContraseñaTexto;
    private javax.swing.JLabel ImagenLogo;
    private javax.swing.JLabel Iniciarsesion;
    private javax.swing.JLabel LoginTexto;
    private javax.swing.JSeparator SeparadorCon;
    private javax.swing.JSeparator SeparadorUsu;
    private javax.swing.JTextField Usuario;
    private javax.swing.JLabel UsuarioTexto;
    // End of variables declaration//GEN-END:variables
}
