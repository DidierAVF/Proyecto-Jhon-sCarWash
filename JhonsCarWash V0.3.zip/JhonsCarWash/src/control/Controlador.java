/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import modelo.autolavado;
import visual.Login;


public class Controlador {
    
    autolavado comiautolavado=new autolavado();
    
    
    public int VerifiAdmin(String Usuario, String Contraseña){
        autolavado Auto = new autolavado();
        int Vali=Auto.verificarcredenciales(Usuario, Contraseña);
        return Vali;
    }
    
    public String registro(String nombre, String cedula, String Placa, String radio1){
     System.out.println(""+nombre+cedula+Placa+radio1);
         System.out.println(""+nombre+cedula+Placa+radio1);
        
    boolean re=comiautolavado.registrar(nombre, cedula,Placa, radio1);
        System.out.println(""+nombre+cedula+Placa+radio1);
        
    
    return "";
    }
}
