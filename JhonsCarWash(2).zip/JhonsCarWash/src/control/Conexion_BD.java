/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author Paula
 */
public class Conexion_BD {
    Connection conectar = null;
    String Usuario="root";
    String Contraseña="1234";
    String BD="autolavado";
    String ip="localhost";
    String puerto="3306";
    
    String cadena="jdbc:mysql://"+ip+":"+puerto+"/"+BD;
    
    public Connection ConexionBD() throws ClassNotFoundException, SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar=(Connection) DriverManager.getConnection(cadena,Usuario,Contraseña);
            JOptionPane.showMessageDialog(null,"Conexión Correcta");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"No se conecto a la base de datos"+e.toString());
        }
        return conectar;
    }
}
