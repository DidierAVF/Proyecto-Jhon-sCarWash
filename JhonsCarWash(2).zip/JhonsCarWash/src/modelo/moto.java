/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Pc
 */
public class moto extends vehiculo {

    private long PrecioMoto=12000;

    public moto() {
    }

    public moto(String placa) {
        super(placa);
        long PrecioMoto = this.PrecioMoto;
    }

    public long getPrecioMoto() {
        return PrecioMoto;
    }

    public void setPrecioMoto(long PrecioMoto) {
        this.PrecioMoto = PrecioMoto;
    }
    

    @Override
    public String toString() {
        return "moto{" + '}';
    }

    @Override
    public double PrecioPromo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
