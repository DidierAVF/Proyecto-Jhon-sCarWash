package modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class menu {

    public void menus() {
        autolavado comiautolavado = new autolavado();

        Scanner dic = new Scanner(System.in);
        int opcion;
        ArrayList<usuario> Usuarios = new ArrayList<usuario>();
        
        System.out.println("Bienvenido Al Autolavado JhonsCarWash");
        do {
            System.out.println("1.  Iniciar Sesion");
            System.out.println("2. Salir");
            opcion = dic.nextInt();

            switch (opcion) {

                case 1:
                   // comiautolavado.iniciarsesion();
                    registrar(Usuarios);
                    for (int i = 0; i <  comiautolavado.getUsuarios().size(); i++) {
                         System.out.println("VERIFICACION DE Q FUNCIONA"+ comiautolavado.getUsuarios().get(i));
                    }
                    
                    
                    break;

                case 2:
                 listar(Usuarios);
              
                    comiautolavado.registrar();

                    break;

                default:
                    System.out.println("Opcion invalida");
                    break;

            }

        } while (opcion != 3);
        
           for (int i = 0; i <  comiautolavado.getUsuarios().size(); i++) {
                         System.out.println("VERIFICACION DE Q FUNCIONA"+ comiautolavado.getUsuarios().get(i));
                    }
        
    }
    
    
 public void listar(ArrayList<usuario> Usuarios){
      autolavado comiautolavado = new autolavado();
     System.out.println("si llegue");
 for (int i = 0; i <  Usuarios.size(); i++) {
                         System.out.println("VERIFICACION DE Q FUNCIONA"+ Usuarios.get(i).getUsuario()+Usuarios.get(i).getContraseña());
                    }
 
 usuario p= new usuario();
 
     
     
 }
 
     public void registrar(ArrayList<usuario> Usuarios) {
        

       
    }
    

}
