
package control;

import modelo.DAO;
import modelo.autolavado;
import visual.Login;

public class Controlador {

    autolavado comiautolavado = new autolavado();
    DAO comidao = new DAO();

    public int VerifiAdmin(String Usuario, String Contraseña) {
        autolavado Auto = new autolavado();
        int Vali = Auto.verificarcredenciales(Usuario, Contraseña);
        return Vali;
    }

    public String registro(String nombre, String cedula, String Placa, String radio1, String Cubiculo) {
        System.out.println("" + nombre + cedula + Placa + radio1);
        System.out.println("" + nombre + cedula + Placa + radio1);

        boolean re = comiautolavado.registrar(nombre, cedula, Placa, radio1, Cubiculo);
        System.out.println("" + nombre + cedula + Placa + radio1);

        return "";
    }

    public String cedula(String cedula) {

        boolean re = comiautolavado.verificarCedulaExiste(cedula);
        if (re == true) {
            comidao.borrarClientePorCedula(cedula);
        } else {
            return "ERROR";
        }
        return "e";

    }
}
