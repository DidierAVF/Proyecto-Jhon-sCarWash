
package modelo;



public class usuario {
    
    
    private String usuario="empleado";
    private String contraseña="empleado123";
    private String adminusuario="admin";
    private String admincontraseña="admin123";
    
    public usuario() {
        
    }
     
    public usuario(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
       
    }
    

    public usuario(String nombre, String usuario, String contraseña, String adminusuario, String admincontraseña, long cedula, int cantidaddelavadas) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.adminusuario = adminusuario;
        this.admincontraseña = admincontraseña;
    }


    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getAdminusuario() {
        return adminusuario;
    }

    public void setAdminusuario(String adminusuario) {
        this.adminusuario = adminusuario;
    }

    public String getAdmincontraseña() {
        return admincontraseña;
    }

    public void setAdmincontraseña(String admincontraseña) {
        this.admincontraseña = admincontraseña;
    }


    @Override
    public String toString() {
        return "usuario{" +  "usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", adminusuario=" + adminusuario + ", admincontrase\u00f1a=" + admincontraseña + '}';
    }
    
    
    
    
    

}