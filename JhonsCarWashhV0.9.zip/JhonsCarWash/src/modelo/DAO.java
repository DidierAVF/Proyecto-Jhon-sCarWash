/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Pc
 */
public class DAO {

    private ResultSet RS;
    Conexion_BD cc = new Conexion_BD();
    Connection con = cc.getConnection();
    private PreparedStatement PS;

    public void register(String nombre1, String cedula1, String Placa1, String radio1, String Cubiculo) {
        String Nombre = nombre1;
        int Cedula = Integer.parseInt(cedula1);
        String Placa = Placa1;
        String Tipo = radio1;
        int Asistencias=Integer.parseInt(Cubiculo);
   
        System.out.println("aa" + Nombre);
        System.out.println("aa" + Cedula);
        System.out.println("aa" + Placa);
        System.out.println("aa" + Tipo);

        String SQL = "INSERT INTO clientes(Nombre, Cedula, Placa, Tipo, Asistencias) VALUES (?,?,?,?,?)";
        try {
            PreparedStatement pst = con.prepareStatement(SQL);
            pst.setString(1, Nombre);
            pst.setInt(2, Cedula);
            pst.setString(3, Placa);
            pst.setString(4, Tipo);
            pst.setInt(5, Asistencias);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se inserto con exito");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexion" + e.getMessage());
        }

    }

    public ArrayList<clientes> almacenardatosBD() {
        ArrayList<clientes> clientList = new ArrayList<>();
        String SQL = "SELECT Nombre, Cedula, Placa, Tipo, Asistencias FROM clientes";
        try {
            PS = con.prepareStatement(SQL);
            RS = PS.executeQuery();
            while (RS.next()) {
                String nombre = RS.getString("Nombre");
                int cedula = RS.getInt("Cedula");
                String placa = RS.getString("Placa");
                String tipo = RS.getString("Tipo");
                int asistencia = RS.getInt("Asistencias");

                clientes cliente = new clientes(nombre, placa, cedula, tipo, asistencia);
                clientList.add(cliente);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching data" + e.getMessage());
        }
        return clientList;
    }

    public void borrarClientePorCedula(String cedula1) {
        int cedula = Integer.parseInt(cedula1);

        String SQL = "DELETE FROM clientes WHERE Cedula = ?";
        try {
            PS = con.prepareStatement(SQL);
            PS.setInt(1, cedula);
            PS.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente con cédula " + cedula + " eliminado correctamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar cliente: " + e.getMessage());
        }

    }

    public ArrayList<moto> almacenarmoto() {
        ArrayList<moto> motoList = new ArrayList<>();
        String sql = "SELECT Placa FROM clientes WHERE Tipo = 'Moto'";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String placa = rs.getString("Placa");
                moto motoObj = new moto(placa);
                motoList.add(motoObj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de data: " + e.getMessage());
        }
        return motoList;
    }
    
    public ArrayList<carro> almacenarcarro() {
        ArrayList<carro> carroList = new ArrayList<>();
        String sql = "SELECT Placa FROM clientes WHERE Tipo = 'Carro'";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String placa = rs.getString("Placa");
                carro carroObj = new carro(placa);
                carroList.add(carroObj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de data: " + e.getMessage());
        }
        return carroList;
    }
    
    
       public ArrayList<camioneta> almacenarcamioneta() {
        ArrayList<camioneta> camionetaList = new ArrayList<>();
        String sql = "SELECT Placa FROM clientes WHERE Tipo = 'Camioneta'";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String placa = rs.getString("Placa");
                camioneta camionetaObj = new camioneta(placa);
                camionetaList.add(camionetaObj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de data: " + e.getMessage());
        }
        return camionetaList;
    }

}
